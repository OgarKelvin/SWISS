import React, { useState } from 'react';
import { MapPin, Phone, Mail, Copy } from 'lucide-react';
import { HUB_LOCATIONS } from '../data/logisticsData';

export default function ContactPage({ copyToClipboard, triggerToast }) {
  const [selectedHub, setSelectedHub] = useState(HUB_LOCATIONS[0]);

  return (
    <main className="py-8 sm:py-12 space-y-12 sm:space-y-16">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* TOP SUPPORT HEADER & INQUIRY FORM */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-extrabold text-rose-500 uppercase tracking-widest">Get in Touch</span>
              <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Contact SWISSDARL</h1>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Have questions about an active waybill, corporate haulage contract, or custom air charter? Our customer care desks operate 24/7.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-start gap-3">
                <MapPin className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">Head Office Address</strong>
                  <span className="text-slate-300">
                    28 Funsho Williams Avenue (Formerly Western Avenue), Ojuelegba, Surulere, Lagos State
                  </span>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-start gap-3">
                <Phone className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">Corporate Telephones</strong>
                  <span className="text-slate-300 block">+234 803 488 2668 (Headquarters Hotline)</span>
                  <span className="text-slate-400 block">+234 916 997 6717 (Abuja Desk)</span>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-start gap-3">
                <Mail className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">Email Desks</strong>
                  <span className="text-slate-300 block break-all">info@swissdarl.com | support@swissdarl.com</span>
                </div>
              </div>
            </div>
          </div>

          {/* GENERAL INQUIRY FORM */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-5 sm:p-6 md:p-8 rounded-2xl">
            <h3 className="text-lg font-bold text-white mb-4">Send a Direct Message</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                triggerToast('Message sent! Our support team will reply via email shortly.');
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  required
                  placeholder="Your Full Name"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500"
                />
                <input
                  type="email"
                  required
                  placeholder="Your Email Address"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="tel"
                  placeholder="Phone Number (+234...)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500"
                />
                <select className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500">
                  <option>General Support Inquiry</option>
                  <option>Waybill / Tracking Dispute</option>
                  <option>Enterprise Haulage Quote</option>
                  <option>Franchise Partnership</option>
                </select>
              </div>

              <textarea
                rows="4"
                required
                placeholder="Write your message or parcel tracking details here..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500"
              />

              <button
                type="submit"
                className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-3 rounded-xl transition text-xs"
              >
                Submit Support Ticket
              </button>
            </form>
          </div>
        </div>

        {/* HUB LOCATOR SECTION */}
        <div className="pt-12 border-t border-slate-800 mt-12">
          <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
            <span className="text-xs font-extrabold text-rose-500 uppercase tracking-widest">Regional Network</span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">SWISSDARL 6 Nigerian Hub Terminals</h2>
            <p className="text-xs text-slate-400 mt-2">
              Select a regional office below to inspect exact physical street addresses, manager contacts, and capacity.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
            {/* HUB SELECTOR */}
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
              {HUB_LOCATIONS.map((hub) => (
                <div
                  key={hub.id}
                  onClick={() => setSelectedHub(hub)}
                  className={`p-4 rounded-xl border transition cursor-pointer ${
                    selectedHub.id === hub.id
                      ? 'bg-slate-900 border-rose-500 shadow-lg'
                      : 'bg-slate-900/40 border-slate-800 hover:bg-slate-900/80'
                  }`}
                >
                  <div className="flex justify-between items-center gap-2 mb-1">
                    <h3 className="font-bold text-white text-sm flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                      <span>{hub.city}</span>
                    </h3>
                    <span className="text-[10px] bg-rose-950 border border-rose-800 text-rose-300 font-bold px-2 py-0.5 rounded-full shrink-0">
                      {hub.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-1">{hub.address}</p>
                </div>
              ))}
            </div>

            {/* SELECTED HUB DETAILS CARD & MAP DIAGRAM */}
            <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 md:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-3 pb-4 border-b border-slate-800">
                <div>
                  <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    ACTIVE TERMINAL
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-1">{selectedHub.city}</h3>
                  <p className="text-xs text-rose-400 font-medium">{selectedHub.type}</p>
                </div>

                <button
                  onClick={() => copyToClipboard(`${selectedHub.city}: ${selectedHub.address} | Tel: ${selectedHub.phone}`)}
                  className="bg-slate-950 border border-slate-700 text-slate-300 hover:text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 shrink-0"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Address</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">Exact Address</span>
                  <p className="text-slate-200 font-medium leading-relaxed">{selectedHub.address}</p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">Terminal Telephone</span>
                  <p className="text-slate-100 font-mono font-bold text-sm flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <a href={`tel:${selectedHub.phone}`} className="hover:underline">{selectedHub.phone}</a>
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">Working Hours</span>
                  <p className="text-slate-200 font-medium">{selectedHub.hours}</p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block mb-1">Terminal Throughput</span>
                  <p className="text-slate-200 font-medium">{selectedHub.capacity}</p>
                </div>
              </div>

              {/* ROUTE CONNECTIVITY SCHEMATIC */}
              <div className="pt-4 border-t border-slate-800">
                <p className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wider">
                  Inter-State Transit Network Schematic
                </p>
                <div className="w-full h-44 sm:h-52 bg-slate-950 rounded-xl border border-slate-800 relative overflow-hidden flex items-center justify-center">
                  <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
                    <line x1="25" y1="75" x2="52" y2="42" stroke="#e11d48" strokeWidth="0.8" strokeDasharray="2,2" />
                    <line x1="25" y1="75" x2="38" y2="70" stroke="#e11d48" strokeWidth="0.8" />
                    <line x1="38" y1="70" x2="58" y2="82" stroke="#e11d48" strokeWidth="0.8" />
                    <line x1="58" y1="82" x2="65" y2="71" stroke="#e11d48" strokeWidth="0.8" />
                    <line x1="52" y1="42" x2="55" y2="18" stroke="#e11d48" strokeWidth="0.8" />

                    {HUB_LOCATIONS.map((h) => {
                      const isSel = h.id === selectedHub.id;
                      return (
                        <g key={h.id} onClick={() => setSelectedHub(h)} className="cursor-pointer">
                          <circle
                            cx={h.coordinates.x}
                            cy={h.coordinates.y}
                            r={isSel ? '4' : '2.5'}
                            fill={isSel ? '#e11d48' : '#64748b'}
                            className={isSel ? 'animate-pulse' : ''}
                          />
                          <text
                            x={h.coordinates.x}
                            y={h.coordinates.y - 4.5}
                            fontSize="3"
                            fill={isSel ? '#ffffff' : '#94a3b8'}
                            fontWeight={isSel ? 'bold' : 'normal'}
                            textAnchor="middle"
                          >
                            {h.city}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
