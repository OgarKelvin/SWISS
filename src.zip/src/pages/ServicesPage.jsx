import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { ALL_SERVICES } from '../data/logisticsData';
import multimodalImg from '../assets/multimodal.jpg';
import haulageTruckImg from '../assets/haulage-truck.jpg';
import warehouseTeamImg from '../assets/warehouse-team.jpg';
import vanLoadingImg from '../assets/van-loading.jpg';

const SERVICE_PHOTOS = [
  multimodalImg,
  haulageTruckImg,
  warehouseTeamImg,
  vanLoadingImg
];

export default function ServicesPage({ navigateTo }) {
  return (
    <main className="w-full bg-slate-950 text-slate-100 py-12 sm:py-16">
      <div className="w-full max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <span className="text-xs font-extrabold uppercase tracking-widest text-rose-500">
              Complete Cargo Portfolio
            </span>
            <h1 className="text-3xl sm:text-4xl font-black text-white mt-1">
              Logistics &amp; Freight Services
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-2 max-w-2xl">
              Air express, customs &amp; port clearance, interstate truck haulage, warehousing, and last-mile fulfillment.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigateTo('shipments', { shipmentsTab: 'rate' })}
            className="bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs sm:text-sm px-6 py-3 rounded-xl transition inline-flex items-center gap-2 self-start md:self-auto cursor-pointer"
          >
            <span>Calculate Freight Rate</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {ALL_SERVICES.map((service, idx) => {
            const IconComp = service.icon;
            const photo = SERVICE_PHOTOS[idx % SERVICE_PHOTOS.length];
            return (
              <div
                key={service.id}
                className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-40 w-full overflow-hidden border-b border-slate-800">
                    <img
                      src={photo}
                      alt={service.title}
                      className="w-full h-full object-cover object-center"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                    <div className="absolute top-3 left-3 p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-rose-400">
                      <IconComp className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="p-6">
                    <h2 className="text-lg font-bold text-white mb-2">{service.title}</h2>
                    <p className="text-xs font-mono text-rose-400 mb-2">{service.sla}</p>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">{service.tagline}</p>
                    {Array.isArray(service.features) && (
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {service.features.slice(0, 3).map((feat) => (
                          <li key={feat} className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>

                <div className="px-6 pb-6 pt-2">
                  <button
                    type="button"
                    onClick={() => navigateTo('shipments', { shipmentsTab: 'ship' })}
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-rose-600 text-white border border-slate-700 hover:border-rose-500 text-xs font-extrabold transition cursor-pointer"
                  >
                    Book This Service
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
}
